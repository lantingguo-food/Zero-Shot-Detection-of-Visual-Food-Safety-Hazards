# FSVH Dataset Format

This document describes the expected format for the Food Safety Visual Hazards (FSVH) dataset.

## Directory Structure

```
data/FSVH/
├── images/
│   ├── train/
│   │   ├── img_0001.jpg
│   │   ├── img_0002.jpg
│   │   └── ...
│   └── test/
│       ├── img_1001.jpg
│       ├── img_1002.jpg
│       └── ...
├── annotations/
│   ├── train.json
│   └── test.json
└── knowledge_graph/
    ├── food_categories.json
    ├── visual_attributes.json
    └── relationships.json
```

## Annotation Format (COCO-style)

The `train.json` and `test.json` files follow COCO format:

```json
{
  "images": [
    {
      "id": 1,
      "file_name": "img_0001.jpg",
      "width": 800,
      "height": 600
    }
  ],
  "annotations": [
    {
      "id": 1,
      "image_id": 1,
      "category_id": 1,
      "bbox": [100, 150, 200, 180],
      "area": 36000,
      "iscrowd": 0
    }
  ],
  "categories": [
    {
      "id": 1,
      "name": "Mold Growth",
      "supercategory": "Biological Contamination",
      "description": "Visible fungal mold contamination with fuzzy texture and discoloration"
    }
  ]
}
```

## Knowledge Graph Format

### food_categories.json

```json
{
  "categories": [
    {
      "id": 0,
      "name": "White Bread",
      "food_type": "Bakery",
      "composition": {
        "water_content": 0.38,
        "ph_level": 5.5,
        "protein": 0.09
      }
    },
    {
      "id": 1,
      "name": "Fresh Strawberries",
      "food_type": "Fruit",
      "composition": {
        "water_content": 0.91,
        "ph_level": 3.3,
        "sugar": 0.05
      }
    }
  ]
}
```

### visual_attributes.json

```json
{
  "attributes": [
    {
      "id": 0,
      "name": "Fuzzy Growth Pattern",
      "category": "Decomposition",
      "description": "Visible fuzzy or hairy growth on food surface indicating mold"
    },
    {
      "id": 1,
      "name": "Green-Blue Discoloration",
      "category": "Appearance",
      "description": "Green or blue color patches indicating mold contamination"
    }
  ]
}
```

### relationships.json

```json
{
  "food_attribute": [
    {
      "food_id": 0,
      "attribute_id": 0,
      "frequency": 0.68,
      "importance": 0.9
    }
  ],
  "food_food": [
    {
      "food_id_1": 0,
      "food_id_2": 1,
      "compositional_similarity": 0.45,
      "hazard_similarity": 0.67,
      "processing_similarity": 0.32
    }
  ],
  "attribute_attribute": [
    {
      "attribute_id_1": 0,
      "attribute_id_2": 1,
      "cooccurrence": 0.73
    }
  ]
}
```

## Semantic Descriptions

Each hazard class should have a detailed description for BERT embedding:

```json
{
  "class_descriptions": {
    "1": "Visible fungal mold contamination growing on bread surface showing fuzzy texture and discoloration ranging from white to green-blue. Common on bakery products stored in humid conditions.",
    "2": "Small transparent glass fragments embedded in food products, often appearing as shiny irregular pieces. Dangerous physical contamination from broken containers or processing equipment.",
    "3": "Insect body parts including legs, wings, or antennae found in food products. Indicates pest infestation or inadequate processing controls."
  }
}
```

## Class Splits

Seen and unseen class splits should be defined:

```json
{
  "seen_classes": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
  "unseen_classes": [21, 22, 23, 24, 25, 26, 27, 28]
}
```

## Hyperclass Hierarchy

For hierarchical relationships:

```json
{
  "hierarchy": {
    "1": ["Biological Contamination", "Mold", "Aspergillus"],
    "2": ["Physical Contamination", "Foreign Objects", "Glass"],
    "3": ["Physical Contamination", "Foreign Objects", "Insect Parts"]
  }
}
```

## Co-occurrence Matrix

Count matrix for class co-occurrences:

```json
{
  "cooccurrence": [
    [100, 15, 8, 3, ...],
    [15, 80, 12, 5, ...],
    ...
  ]
}
```

This is a C×C matrix where element (i,j) is the count of times classes i and j appear together.
